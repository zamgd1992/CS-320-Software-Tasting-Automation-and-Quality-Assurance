package contact;

import java.util.ArrayList;
import java.util.List;

public class ContactService{
	
	static public List<Contact> contactList = new ArrayList<Contact>();
	
	
	public static boolean addContact(String contactID, String firstName, String lastName, String phone, String address) {
		
		for (int i = 0; i < contactList.size(); i++) {
			if (contactList.get(i).getContactID().equals(contactID)) {
				throw new IllegalArgumentException("ID already in use");
			}
		}
		
		Contact newContact = new Contact(contactID, firstName, lastName, phone, address);
		contactList.add(newContact);
		return true;
	}

	public static void deleteContact(String contactID) {
		for (int i = 0; i < contactList.size(); i++) {
			if ((contactList).get(i).getContactID().equals(contactID)) {
				contactList.remove(i);
			}
		}
	}
	
	public static void updateFirstName(String contactID, String newFirstName) {
		for (int i = 0; i < contactList.size(); i++) {
			if ((contactList).get(i).getContactID().equals(contactID)) {
				contactList.get(i).changeFirstName(newFirstName);
			}
		}
	}
	
	public static void updateLastName(String contactID, String newLastName) {
		for (int i = 0; i < contactList.size(); i++) {
			if ((contactList).get(i).getContactID().equals(contactID)) {
				contactList.get(i).changeLastName(newLastName);
			}
		}
	}
	
	public static void updateNumber(String contactID, String newNumber) {
		for (int i = 0; i < contactList.size(); i++) {
			if ((contactList).get(i).getContactID().equals(contactID)) {
				contactList.get(i).changePhone(newNumber);
			}
		}
	}
	
	public static void updateAddress(String contactID, String newAddress) {
		for (int i = 0; i < contactList.size(); i++) {
			if ((contactList).get(i).getContactID().equals(contactID)) {
				contactList.get(i).changeAddress(newAddress);
			}
		}
	}
	
}
