package appointment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;



public class AppointmentService {
	static public List<Appointment> appointmentList = new ArrayList<Appointment>();
	
	
	public static boolean addAppointment(String appointmentID, Date appointmentDate, String appointmentDescription) {
		
		for (int i = 0; i < appointmentList.size(); i++) {
			if (appointmentList.get(i).getAppointmentID().equals(appointmentID)) {
				throw new IllegalArgumentException("ID already in use");
			}
		}
		
		Appointment newAppointment = new Appointment(appointmentID, appointmentDate, appointmentDescription);
		appointmentList.add(newAppointment);
		return true;
	}

	public static void deleteTask(String taskID) {
		for (int i = 0; i < appointmentList.size(); i++) {
			if ((appointmentList).get(i).getAppointmentID().equals(taskID)) {
				appointmentList.remove(i);
			}
		}
	}

	public static void updateAppointmentDate(String appointmentID, Date newDate) {
		for (int i = 0; i < appointmentList.size(); i++) {
			if ((appointmentList).get(i).getAppointmentID().equals(appointmentID)) {
				appointmentList.get(i).changeAppointmentDate(newDate);
			}
		}
	}
	
	public static void updateAppointmentDescription(String appointmentID, String newAppointmentDescription) {
		for (int i = 0; i < appointmentList.size(); i++) {
			if ((appointmentList).get(i).getAppointmentID().equals(appointmentID)) {
				appointmentList.get(i).changeAppointmentDescription(newAppointmentDescription);
			}
		}
	}
}
