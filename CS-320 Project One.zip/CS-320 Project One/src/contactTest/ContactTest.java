package contactTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contact.Contact;

class ContactTest {

	@Test
	void testContact() {
		Contact contactClass = new Contact("12345", "Michael", "Scott", "8005555555", "1725 Slough Ave");
		assertTrue(contactClass.getContactID().equals("12345"));
		assertTrue(contactClass.getFirstName().equals("Michael"));
		assertTrue(contactClass.getLastName().equals("Scott"));
		assertTrue(contactClass.getPhone().equals("8005555555"));
		assertTrue(contactClass.getAddress().equals("1725 Slough Ave"));
	}
	
	@Test
	void testNewContactIDToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "Michaelllll", "Scott", "8005555555", "1725 Slough Ave");
		});		
	}
	
	@Test
	void testNewContactIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Michaelllll", "Scott", "8005555555", "1725 Slough Ave");
		});		
	}
	
	@Test
	void testNewContactFirstNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Michaelllll", "Scott", "8005555555", "1725 Slough Ave");
		});		
	}
	
	@Test
	void testNewContactFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", null, "Scott", "8005555555", "1725 Slough Ave");
		});		
	}
	
	@Test
	void testNewContactLastNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Michael", "Scotttttttt", "8005555555", "1725 Slough Ave");
		});		
	}
	
	@Test
	void testNewContactLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Michael", null, "8005555555", "1725 Slough Ave");
		});		
	}
	
	@Test
	void testNewContactAddressToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Michael", "Scott", "8005555555", "1725 Slough Avenue 123456789 30");
		});		
	}
	
	@Test
	void testNewContactAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Michael", "Scott", "8005555555", null);
		});		
	}
	
	@Test
	void testNewContactPhoneToShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Michael", "Scott", "800555555", "1725 Slough Ave");
		});		
	}
	
	@Test
	void testNewContactPhoneToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Michael", "Scott", "80055555555", "1725 Slough Ave");
		});		
	}
	
	@Test
	void testNewContactPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Michael", "Scott", null, "1725 Slough Ave");
		});		
	}
	
	@Test
	void testNewContactPhoneNotDigits() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Michael", "Scott", "801A555555", "1725 Slough Ave");
		});		
	}
	
	@Test
	void testChangeContactFirstNameToLong() {
		Contact contact = new Contact("12345", "Michael", "Scott", "8005555555", "1725 Slough Ave");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.changeFirstName("Michaelllll");
		});		
	}
	
	@Test
	void testChangeContactFirstNameNull() {
		Contact contact = new Contact("12345", "Michael", "Scott", "8005555555", "1725 Slough Ave");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.changeFirstName(null);
		});		
	}
	
	@Test
	void testChangeContactLastNameToLong() {
		Contact contact = new Contact("12345", "Michael", "Scott", "8005555555", "1725 Slough Ave");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.changeLastName("Scotttttttt");
		});		
	}
	
	@Test
	void testChangeContactLastNameNull() {
		Contact contact = new Contact("12345", "Michael", "Scott", "8005555555", "1725 Slough Ave");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.changeLastName(null);
		});		
	}
	
	@Test
	void testChangeContactAddressToLong() {
		Contact contact = new Contact("12345", "Michael", "Scott", "8005555555", "1725 Slough Ave");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.changeAddress("1725 Slough Avenue 123456789 30");
		});		
	}
	
	@Test
	void testChangeContactAddressNull() {
		Contact contact = new Contact("12345", "Michael", "Scott", "8005555555", "1725 Slough Ave");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.changeAddress(null);
		});		
	}
	
	@Test
	void testChangeContactPhoneToShort() {
		Contact contact = new Contact("12345", "Michael", "Scott", "8005555555", "1725 Slough Ave");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.changePhone("800555555");
		});		
	}
	
	@Test
	void testChangeContactPhoneToLong() {
		Contact contact = new Contact("12345", "Michael", "Scott", "8005555555", "1725 Slough Ave");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.changePhone("80055555555");
		});		
	}
	
	@Test
	void testChangeContactPhoneNull() {
		Contact contact = new Contact("12345", "Michael", "Scott", "8005555555", "1725 Slough Ave");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.changePhone(null);
		});		
	}
	
	@Test
	void testChangeContactPhoneNotDigit() {
		Contact contact = new Contact("12345", "Michael", "Scott", "8005555555", "1725 Slough Ave");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.changePhone("801A555555");
		});		
	}

}
