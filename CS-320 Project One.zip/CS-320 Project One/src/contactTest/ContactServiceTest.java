package contactTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import contact.ContactService;

class ContactServiceTest {

	@BeforeEach
	void setUpListForTesting() {
		ContactService.addContact("0", "Bob", "Vance", "1234567890", "123 Some Ave");
		ContactService.addContact("1", "Michael", "Scott", "8005555555", "1725 Slough Ave");
		ContactService.addContact("2", "Al", "Capone", "0987654321", "345 Chi-Town");
	}
	
	@Test
	void testContactServiceCanBeAdded() {
		assertTrue(ContactService.addContact("3", "Al", "Capone", "0987654321", "345 Chi-Town"));
	}

	@Test
	void testContactServiceAddToList() {
		assertTrue(ContactService.contactList.get(0).getFirstName().equals("Bob"));
		assertTrue(ContactService.contactList.get(0).getLastName().equals("Vance"));
		assertTrue(ContactService.contactList.get(0).getPhone().equals("1234567890"));
		assertTrue(ContactService.contactList.get(0).getAddress().equals("123 Some Ave"));
		assertTrue(ContactService.contactList.get(1).getFirstName().equals("Michael"));
		assertTrue(ContactService.contactList.get(1).getLastName().equals("Scott"));
		assertTrue(ContactService.contactList.get(1).getPhone().equals("8005555555"));
		assertTrue(ContactService.contactList.get(1).getAddress().equals("1725 Slough Ave"));
		assertTrue(ContactService.contactList.get(2).getFirstName().equals("Al"));
		assertTrue(ContactService.contactList.get(2).getLastName().equals("Capone"));
		assertTrue(ContactService.contactList.get(2).getPhone().equals("0987654321"));
		assertTrue(ContactService.contactList.get(2).getAddress().equals("345 Chi-Town"));
	}
	
	@Test
	void testAddContactDuplicateID() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			ContactService.addContact("0", "Michael", "Scott", "8005555555", "1725 Slough Ave");
		});	
	}
	
	@Test
	void testContactServiceDeleteFromList() {
		ContactService.deleteContact("0");
		assertTrue(ContactService.contactList.get(0).getFirstName().equals("Michael"));
		assertTrue(ContactService.contactList.get(1).getFirstName().equals("Al"));
	}
	
	@Test
	void testContactServiceUpdateContactFirstName() {
		assertTrue(ContactService.contactList.get(0).getFirstName().equals("Bob"));
		ContactService.updateFirstName("0", "Philis");
		assertTrue(ContactService.contactList.get(0).getFirstName().equals("Philis"));
	}
	
	@Test
	void testContactServiceUpdateContactLastName() {
		assertTrue(ContactService.contactList.get(0).getLastName().equals("Vance"));
		ContactService.updateLastName("0", "Burgers");
		assertTrue(ContactService.contactList.get(0).getLastName().equals("Burgers"));
	}
	
	@Test
	void testContactServiceUpdateContactNumber() {
		assertTrue(ContactService.contactList.get(0).getPhone().equals("1234567890"));
		ContactService.updateNumber("0", "8005555555");
		assertTrue(ContactService.contactList.get(0).getPhone().equals("8005555555"));
	}
	
	@Test
	void testContactServiceUpdateContactAddress() {
		assertTrue(ContactService.contactList.get(0).getAddress().equals("123 Some Ave"));
		ContactService.updateAddress("0", "1725 Slough Ave");
		assertTrue(ContactService.contactList.get(0).getAddress().equals("1725 Slough Ave"));
	}
	
	@Test
	void testPhoneNotDigits() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			ContactService.addContact("0", "Michael", "Scott", "80055555f5", "1725 Slough Ave");
		});
	}
	
	@AfterEach
	void removeAllElementsFromList() {
		ContactService.deleteContact("0");
		ContactService.deleteContact("1");
		ContactService.deleteContact("2");
	}

}
