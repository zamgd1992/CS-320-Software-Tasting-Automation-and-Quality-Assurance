package appointmentTest;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import appointment.AppointmentService;

class AppointmentServiceTest {

	@BeforeEach
	void setupListForTesting() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		@SuppressWarnings("deprecation")
		Date apptDate = new Date(year, month, day, hours, minutes);
		AppointmentService.addAppointment("0", apptDate, "Doctor visit");
		AppointmentService.addAppointment("1", apptDate, "Dental visit");
		AppointmentService.addAppointment("2", apptDate, "Meet with client");
	}
	
	@Test
	void testAppointmentServiceCanBeAdded() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		@SuppressWarnings("deprecation")
		Date apptDate = new Date(year, month, day, hours, minutes);
		assertTrue(AppointmentService.addAppointment("3", apptDate, "Meet with client"));
	}
	
	@Test
	void testAppointmentServiceDeleteFromList() {
		AppointmentService.deleteTask("0");
		assertTrue(AppointmentService.appointmentList.get(1).getAppointmentDescription().equals("Dental visit"));
		assertTrue(AppointmentService.appointmentList.get(2).getAppointmentDescription().equals("Meet with client"));
	}
	
	@Test
	void testAddAppointmentWithDuplicateID() {
		Date newDate = new Date();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			AppointmentService.addAppointment("0", newDate, "Doctor visit");
		});
	}
	
	@SuppressWarnings("deprecation")
	@Test
	void testUpdateDate() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		Date apptDate = new Date(year, month, day, hours, minutes);
		assertTrue(AppointmentService.appointmentList.get(1).getAppointmentDate().equals(apptDate));
		year = 130;
		Date newDate = new Date(year, month, day, hours, minutes);
		AppointmentService.updateAppointmentDate("0", newDate);
		assertTrue(AppointmentService.appointmentList.get(1).getAppointmentDate().equals(newDate));
	}
		
	@Test
	void testUpdateDescription() {
		assertTrue(AppointmentService.appointmentList.get(1).getAppointmentDescription().equals("Doctor visit"));
		AppointmentService.updateAppointmentDescription("0", "Call client");
		assertTrue(AppointmentService.appointmentList.get(1).getAppointmentDescription().equals("Call client"));
	}
	
	@AfterEach
	void removeListElements() {
		AppointmentService.deleteTask("0");
		AppointmentService.deleteTask("1");
		AppointmentService.deleteTask("2");
	}

}
