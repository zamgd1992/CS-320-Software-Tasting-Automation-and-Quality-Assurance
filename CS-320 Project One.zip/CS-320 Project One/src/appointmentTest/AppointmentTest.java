package appointmentTest;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import appointment.Appointment;

class AppointmentTest {

	@Test
	void testAppointment() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		@SuppressWarnings("deprecation")
		Date apptDate = new Date(year, month, day, hours, minutes);
		Appointment appointmentClass = new Appointment("12345", apptDate, "Doctors Visit");
		assertTrue(appointmentClass.getAppointmentID().equals("12345"));
		assertTrue(appointmentClass.getAppointmentDate().equals(apptDate));
		assertTrue(appointmentClass.getAppointmentDescription().equals("Doctors Visit"));
	}

	@Test
	void testNewAppointmentIDToLong() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		@SuppressWarnings("deprecation")
		Date apptDate = new Date(year, month, day, hours, minutes);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345678910", apptDate, "Doctors Visit");
		});		
	}
	
	@Test
	void testNewAppointmentIDNull() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		@SuppressWarnings("deprecation")
		Date apptDate = new Date(year, month, day, hours, minutes);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null,  apptDate, "Doctors Visit");
		});
	}
	
	@Test
	void testNewAppointmentDateAlreadyPast() {
		int year = 120;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		@SuppressWarnings("deprecation")
		Date apptDate = new Date(year, month, day, hours, minutes);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345", apptDate, "Doctors Visit");
		});		
	}
	
	@Test
	void testNewAppointmentDateNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345", null, "Doctors Visit");
		});
	}
	
	@SuppressWarnings("deprecation")
	@Test
	void testChangeDateToPastDate() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		Date apptDate = new Date(year, month, day, hours, minutes);
		Appointment appointmentClass = new Appointment("12345", apptDate, "Doctors Visit");
		assertTrue(appointmentClass.getAppointmentDate().equals(apptDate));
		year = 0;
		apptDate.setYear(year);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appointmentClass.changeAppointmentDate(apptDate);
		});	
	}
	
	@SuppressWarnings("deprecation")
	@Test
	void testChangeDateToNull() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		Date apptDate = new Date(year, month, day, hours, minutes);
		Appointment appointmentClass = new Appointment("12345", apptDate, "Doctors Visit");
		assertTrue(appointmentClass.getAppointmentDate().equals(apptDate));
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appointmentClass.changeAppointmentDate(null);
		});	
	}
	
	@SuppressWarnings("deprecation")
	@Test
	void testChangeAppointmentDate() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		Date apptDate = new Date(year, month, day, hours, minutes);
		Appointment appointmentClass = new Appointment("12345", apptDate, "Doctors Visit");
		assertTrue(appointmentClass.getAppointmentDate().equals(apptDate));
		year = 124;
		apptDate.setYear(year);
		appointmentClass.changeAppointmentDate(apptDate);
		assertTrue(appointmentClass.getAppointmentDate().equals(apptDate));
	}
		
	@Test
	void testNewAppoinmentDescriptionToLong() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		@SuppressWarnings("deprecation")
		Date apptDate = new Date(year, month, day, hours, minutes);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345", apptDate, "The description for this appointment is too long  .");
		});		
	}
	
	@Test
	void testNewAppointmentDescriptionNull() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		@SuppressWarnings("deprecation")
		Date apptDate = new Date(year, month, day, hours, minutes);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("12345", apptDate, null);
		});
	}
	
	@SuppressWarnings("deprecation")
	@Test
	void testChangeAppointmentDescription() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		Date apptDate = new Date(year, month, day, hours, minutes);
		Appointment appointmentClass = new Appointment("12345", apptDate, "Doctors Visit");
		assertTrue(appointmentClass.getAppointmentDescription().equals("Doctors Visit"));
		appointmentClass.changeAppointmentDescription("Dentist visit");
		assertTrue(appointmentClass.getAppointmentDescription().equals("Dentist visit"));
	}
	
	@Test
	void testChangeDescriptionToLong() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		@SuppressWarnings("deprecation")
		Date apptDate = new Date(year, month, day, hours, minutes);
		Appointment appointmentClass = new Appointment("12345", apptDate, "Doctors Visit");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appointmentClass.changeAppointmentDescription("The description for this appointment is too long  .");
		});
	}

	@Test
	void testChangeDescriptionToNull() {
		int year = 125;
		int month = 1;
		int day = 30;
		int hours = 8;
		int minutes = 30;
		@SuppressWarnings("deprecation")
		Date apptDate = new Date(year, month, day, hours, minutes);
		Appointment appointmentClass = new Appointment("12345", apptDate, "Doctors Visit");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			appointmentClass.changeAppointmentDescription(null);
		});
	}

}
