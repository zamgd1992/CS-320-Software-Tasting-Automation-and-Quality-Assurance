package taskTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import task.TaskService;

class TaskServiceTest {

	@BeforeEach
	void setupListForTesting() {
		TaskService.addTask("0", "File work", "Organise work files in alphabetical order");
		TaskService.addTask("1", "Make calls", "Call all clients on list");
		TaskService.addTask("2", "Take out grabage", "Empty all trash bins and take out to dumpster");
	}
	
	@Test
	void testTaskServiceCanBeAdded() {
		assertTrue(TaskService.addTask("3", "Take out grabage", "Empty all trash bins and take out to dumpster"));
	}
	
	@Test
	void testTaskServiceDeleteFromList() {
		TaskService.deleteTask("0");
		assertTrue(TaskService.taskList.get(1).getTaskName().equals("Make calls"));
		assertTrue(TaskService.taskList.get(2).getTaskName().equals("Take out grabage"));
	}
	
	@Test
	void testTaskServiceUpdateTaskName() {
		assertTrue(TaskService.taskList.get(0).getTaskName().equals("Take out grabage"));
		TaskService.updateTaskName("3", "Make calls");
		assertTrue(TaskService.taskList.get(0).getTaskName().equals("Make calls"));
	}

	@Test
	void testTaskServiceUpdateTaskDescription() {
		assertTrue(TaskService.taskList.get(0).getTaskDescription().equals("Organise work files in alphabetical order"));
		TaskService.updateTaskDescription("0", "Call all clients on list");
		assertTrue(TaskService.taskList.get(0).getTaskDescription().equals("Call all clients on list"));
	}
	
	@Test
	void testAddTaskWithDuplicateID() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			TaskService.addTask("0", "File work", "Organise work files in alphabetical order");
		});
	}
		
	@AfterEach
	void removeListElements() {
		TaskService.deleteTask("0");
		TaskService.deleteTask("1");
		TaskService.deleteTask("2");
	}

}
