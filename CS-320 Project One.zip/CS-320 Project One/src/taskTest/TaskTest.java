package taskTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import task.Task;

class TaskTest {

	@Test
	void testTask() {
		Task taskClass = new Task("12345", "File work", "Put work files in alphabetical order");
		assertTrue(taskClass.getTaskID().equals("12345"));
		assertTrue(taskClass.getTaskName().equals("File work"));
		assertTrue(taskClass.getTaskDescription().equals("Put work files in alphabetical order"));
	}

	@Test
	void testNewTaskIDToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678910", "File work", "Put work files in alphabetical order");
		});		
	}
	
	@Test
	void testNewTaskIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "File work", "Put work files in alphabetical order");
		});
	}
	
	@Test
	void testNewTaskNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678910", "This name is too long", "Put work files in alphabetical order");
		});		
	}
	
	@Test
	void testNewTaskNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345", null, "Put work files in alphabetical order");
		});
	}
	@Test
	void testNewTaskDescriptionToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345678910", "File work", "The description for this task is too long, it is 51");
		});		
	}
	
	@Test
	void testNewTaskDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("12345", "File work", null);
		});
	}
	
	@Test
	void testChangeNameToLong() {
		Task taskClass = new Task("12345", "File work", "Put work files in alphabetical order");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			taskClass.changeTaskName("This name is too long");
		});
	}
	
	@Test
	void testChangeDescriptionToLong() {
		Task taskClass = new Task("12345", "File work", "Put work files in alphabetical order");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			taskClass.changeTaskDescription("The description for this task is too long, it is 51");
		});
	}
	
	@Test
	void testChangeNameToNull() {
		Task taskClass = new Task("12345", "File work", "Put work files in alphabetical order");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			taskClass.changeTaskName(null);
		});
	}
	
	@Test
	void testChangeDescriptionToNull() {
		Task taskClass = new Task("12345", "File work", "Put work files in alphabetical order");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			taskClass.changeTaskDescription(null);
		});
	}

}
