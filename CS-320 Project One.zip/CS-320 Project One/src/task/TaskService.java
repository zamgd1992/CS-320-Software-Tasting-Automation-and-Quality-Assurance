package task;

import java.util.ArrayList;
import java.util.List;

public class TaskService {
	static public List<Task> taskList = new ArrayList<Task>();
	
	
	public static boolean addTask(String taskID, String taskName, String taskDescription) {
		
		for (int i = 0; i < taskList.size(); i++) {
			if (taskList.get(i).getTaskID().equals(taskID)) {
				throw new IllegalArgumentException("ID already in use");
			}
		}
		
		Task newTask = new Task(taskID, taskName, taskDescription);
		taskList.add(newTask);
		return true;
	}

	public static void deleteTask(String taskID) {
		for (int i = 0; i < taskList.size(); i++) {
			if ((taskList).get(i).getTaskID().equals(taskID)) {
				taskList.remove(i);
			}
		}
	}
	
	public static void updateTaskName(String taskID, String newTaskName) {
		for (int i = 0; i < taskList.size(); i++) {
			if ((taskList).get(i).getTaskID().equals(taskID)) {
				taskList.get(i).changeTaskName(newTaskName);
			}
		}
	}
	
	public static void updateTaskDescription(String taskID, String newTaskDescription) {
		for (int i = 0; i < taskList.size(); i++) {
			if ((taskList).get(i).getTaskID().equals(taskID)) {
				taskList.get(i).changeTaskDescription(newTaskDescription);
			}
		}
	}
}
